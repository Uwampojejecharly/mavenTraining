package bonjour;

import fr.charly.mavenTraining.Hello;

public class PrintHello {

	public static void main(String... arg) {
		Hello hello = new Hello();
		hello.printGreetings("Dupont", "Michel");

	}

}
